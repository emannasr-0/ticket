<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use BeyondCode\Mailbox\Facades\Mailbox;
use BeyondCode\Mailbox\InboundEmail;

class MailgunWidgetsController extends Controller
{
    public function store()
    {
        Mailbox::from('nahedfathi940@gmail.com', function (InboundEmail $email) {
            $email->forward('nahed581213@gmail.com');
        });
        return response()->json(['status' => 'ok']);
    }
}
