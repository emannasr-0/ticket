<?php

namespace App\Mailboxes;

use BeyondCode\Mailbox\InboundEmail;
use BeyondCode\Mailbox\Mails\Concerns\HandlesEmail;
use Illuminate\Support\Facades\Mail;

class MyMailbox
{
    use HandlesEmail;

    public function __invoke(InboundEmail $email)
    {

        Mail::raw('Thank you for your email!', function ($message) use ($email) {
            $message->to($email->from())->subject('Re: ' . $email->subject());
        });
    }
}
